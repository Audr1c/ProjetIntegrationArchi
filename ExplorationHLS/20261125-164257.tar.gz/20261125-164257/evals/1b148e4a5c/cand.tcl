# Candidat de l'exploration HLS (genere par ExplorationHLS) : L1 II1 x2 DP  L2 II1  L3   FC 
project load {/tp/xph3sei/xph3sei706/ProjetIntegrationArchi/ExplorationHLS/work/w0/Catapult.ccs}
solution new -state assembly
set ::explo_log [open directives_log.txt w]
# explo_try : essaie les chemins dans l'ordre ; journal OK/KO (KO + essentielle = resultat ecarte)
proc explo_try {what essential paths args} {
    foreach p $paths {
        if {![catch {directive set $p {*}$args}]} {
            puts $::explo_log "OK\t$essential\t$what\t$p $args"
            return 1
        }
    }
    puts $::explo_log "KO\t$essential\t$what\t$paths $args"
    return 0
}
explo_try {layer1 MAC pipelinees} 1 [list {/cnn/layer1:inst/core/main/CONV_CO}] -PIPELINE_INIT_INTERVAL 1
explo_try {layer1 2 MAC/cycle} 1 [list {/cnn/layer1:inst/core/main/CONV_CO/CONV_ROW/CONV_COL/MAC_CI/MAC_M/MAC_N}] -UNROLL 2
explo_try {layer1 poids en 2 bancs} 1 [list {/cnn/layer1:inst/ker1.v.rom:rsc}] -INTERLEAVE 2
explo_try {layer1 sortie double port} 1 [list {/cnn/layer1:inst/core/image2:rsc}] -MAP_TO_MODULE Xilinx_RAMS.BLOCK_DPRAM_RBW
explo_try {layer1 entree double port} 0 [list {/cnn/image:rsc}] -MAP_TO_MODULE Xilinx_RAMS.BLOCK_DPRAM_RBW
explo_try {layer2 MAC pipelinees} 1 [list {/cnn/layer2:inst/core/main/CONV_CO}] -PIPELINE_INIT_INTERVAL 1
explo_try {pool1_chan : 1 etage(s)} 0 [list {/cnn/pool1_chan:cns}] -STAGE_REPLICATION 1
explo_try {pool2_chan : 1 etage(s)} 0 [list {/cnn/pool2_chan:cns}] -STAGE_REPLICATION 1
close $::explo_log
go extract
puts "EXPLO_EXTRACT_OK"
exit
