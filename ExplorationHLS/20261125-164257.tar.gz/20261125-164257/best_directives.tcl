# Directives retenues par l'exploration HLS, run 20261125-164257
# L1 II1 x2 DP  L2 II1 x2 DP  L3   FC 
# latence 9.02 M cycles, BRAM18 108, DSP 13.0, LUT 5792.0, slack 0.2849929999999983 ns
# Usage : dans hls/cnn.tcl, set DIRECTIVES_FILE ExplorationHLS/runs/20261125-164257/best_directives.tcl
# (source apres go assembly ; cnn_try essaie les chemins dans l'ordre et previent s'il n'en trouve aucun)

cnn_try [list {/cnn/layer1:inst/core/main/CONV_CO}] -PIPELINE_INIT_INTERVAL 1   ;# layer1 MAC pipelinees
cnn_try [list {/cnn/layer1:inst/core/main/CONV_CO/CONV_ROW/CONV_COL/MAC_CI/MAC_M/MAC_N}] -UNROLL 2   ;# layer1 2 MAC/cycle
cnn_try [list {/cnn/layer1:inst/ker1.v.rom:rsc}] -INTERLEAVE 2   ;# layer1 poids en 2 bancs
cnn_try [list {/cnn/layer1:inst/core/image2:rsc}] -MAP_TO_MODULE Xilinx_RAMS.BLOCK_DPRAM_RBW   ;# layer1 sortie double port
cnn_try [list {/cnn/image:rsc}] -MAP_TO_MODULE Xilinx_RAMS.BLOCK_DPRAM_RBW   ;# layer1 entree double port
cnn_try [list {/cnn/layer2:inst/core/main/CONV_CO}] -PIPELINE_INIT_INTERVAL 1   ;# layer2 MAC pipelinees
cnn_try [list {/cnn/layer2:inst/core/main/CONV_CO/CONV_ROW/CONV_COL/MAC_CI/MAC_M/MAC_N}] -UNROLL 2   ;# layer2 2 MAC/cycle
cnn_try [list {/cnn/layer2:inst/ker2.v.rom:rsc}] -INTERLEAVE 2   ;# layer2 poids en 2 bancs
cnn_try [list {/cnn/layer2:inst/core/image4:rsc}] -MAP_TO_MODULE Xilinx_RAMS.BLOCK_DPRAM_RBW   ;# layer2 sortie double port
cnn_try [list {/cnn/pool1_chan:cns}] -MAP_TO_MODULE Xilinx_RAMS.BLOCK_DPRAM_RBW   ;# layer2 entree double port
cnn_try [list {/cnn/pool1_chan:cns}] -STAGE_REPLICATION 1   ;# pool1_chan : 1 etage(s)
cnn_try [list {/cnn/pool2_chan:cns}] -STAGE_REPLICATION 1   ;# pool2_chan : 1 etage(s)
